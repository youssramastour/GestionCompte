﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TPCreateImage
{
    public partial class FormPictureView : Form
    {
        public FormPictureView()
        {
            InitializeComponent();
           pictureBoximage.Image = Image.FromFile("C:\\Users\\dell\\Pictures\\aa.jpg");
        }

        
        private void btmclose_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("voulez-vous quitter ce formulaire?", "Title", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
                this.Close();
        }


        private void btmcolor_Click(object sender, EventArgs e)
        {
            /*if(colorDialog1.ShowDialog=.OK)
            {
                pictureBoximage.BackColor=
            }
            */
        }

        private void btmClear_Click(object sender, EventArgs e)
        {
            pictureBoximage.Image = null;
        }

        private void btmAfficher_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("voulez-vous affichercImage?","Title", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (r==DialogResult.Yes)
            {
                //pictureBoximage.Load(openFileDialog1.FileName);
                pictureBoximage.Image = Image.FromFile("C:\\Users\\dell\\Pictures\\Saved Pictures\\photo.jpg");
            }
        }

        private void checkrecherche_CheckedChanged(object sender, EventArgs e)
        {
            if (checkrecherche.Checked)
                pictureBoximage.SizeMode = PictureBoxSizeMode.StretchImage;
            else
                pictureBoximage.SizeMode = PictureBoxSizeMode.Normal;

        }

        private void pictureBoximage_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        /*--------En relation avec la classe Compt
private void button2_Click(object sender, EventArgs e)
{
   double start = double.Parse(TextBox.Text);
   string type_end=combox.text;
   double taux;
   devise d1=new DEvise(start.Combox.text);
   if(type_end=="EU")
   {
    taux=10;
   }
   else
   taux=1;
   double res=S1.convertto(taux);
   text.text=res.tostring();
}
*/
    }
}
