﻿namespace GESTIONBank
{
    partial class FormulaireDebiter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtsomme = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btmdebiter = new System.Windows.Forms.Button();
            this.textBoxsolde = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxnew = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Somme";
            // 
            // txtsomme
            // 
            this.txtsomme.Location = new System.Drawing.Point(119, 56);
            this.txtsomme.Name = "txtsomme";
            this.txtsomme.Size = new System.Drawing.Size(231, 22);
            this.txtsomme.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(304, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Formulaire de debiter\r\n";
            // 
            // btmdebiter
            // 
            this.btmdebiter.Location = new System.Drawing.Point(477, 197);
            this.btmdebiter.Name = "btmdebiter";
            this.btmdebiter.Size = new System.Drawing.Size(175, 23);
            this.btmdebiter.TabIndex = 3;
            this.btmdebiter.Text = "Debiter";
            this.btmdebiter.UseVisualStyleBackColor = true;
            this.btmdebiter.Click += new System.EventHandler(this.btmdebiter_Click);
            // 
            // textBoxsolde
            // 
            this.textBoxsolde.Location = new System.Drawing.Point(120, 102);
            this.textBoxsolde.Name = "textBoxsolde";
            this.textBoxsolde.Size = new System.Drawing.Size(231, 22);
            this.textBoxsolde.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Solde";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Nouveau solde";
            // 
            // textBoxnew
            // 
            this.textBoxnew.Location = new System.Drawing.Point(121, 166);
            this.textBoxnew.Name = "textBoxnew";
            this.textBoxnew.Size = new System.Drawing.Size(231, 22);
            this.textBoxnew.TabIndex = 9;
            // 
            // FormulaireDebiter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 253);
            this.Controls.Add(this.textBoxnew);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxsolde);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btmdebiter);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsomme);
            this.Controls.Add(this.label1);
            this.Name = "FormulaireDebiter";
            this.Text = "FormulaireDebiter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtsomme;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btmdebiter;
        private System.Windows.Forms.TextBox textBoxsolde;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxnew;
    }
}