﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GESTIONBank
{
    public partial class FormulaireDebiter : Form
    {
        public FormulaireDebiter()
        {
            InitializeComponent();
        }

        private void btmdebiter_Click(object sender, EventArgs e)
        {
            float somme = int.Parse(txtsomme.Text);
            float solde = int.Parse(textBoxsolde.Text);
            float res = solde- somme;
            res = int.Parse(textBoxnew.Text);
        }
    }
}
