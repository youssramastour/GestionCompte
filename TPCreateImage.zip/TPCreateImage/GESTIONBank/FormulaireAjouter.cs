﻿using Atelier1_G31;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GESTIONBank
{
    public partial class FormulaireAjouter : Form
    {
        public FormulaireAjouter()
        {
            InitializeComponent();
        }
        
        private void btmAjoutre_Click(object sender, EventArgs e)
        {
            Client p = new Client(textBox1.Text, textBox2.Text, textBox3.Text,int.Parse(textBox4.Text),comboBox1.Text);
            Program.liste.Add(p);
            vider();
        }
        public void vider()
        {
            textBox1.Text = "";
            textBox2.ResetText();
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
            textBox1.Focus();
        }

        private void FormulaireAjouter_Load(object sender, EventArgs e)
        {

        }
    }
}
