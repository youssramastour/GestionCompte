﻿namespace GESTIONBank
{
    partial class FormumlaireModfierCompte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxsolde = new System.Windows.Forms.CheckBox();
            this.checkBoxsomme = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxsomme = new System.Windows.Forms.TextBox();
            this.textBoxsolde = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonEN = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxsolde);
            this.groupBox1.Controls.Add(this.checkBoxsomme);
            this.groupBox1.Location = new System.Drawing.Point(42, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(587, 99);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choix de modification";
            // 
            // checkBoxsolde
            // 
            this.checkBoxsolde.AutoSize = true;
            this.checkBoxsolde.Location = new System.Drawing.Point(263, 36);
            this.checkBoxsolde.Name = "checkBoxsolde";
            this.checkBoxsolde.Size = new System.Drawing.Size(64, 21);
            this.checkBoxsolde.TabIndex = 1;
            this.checkBoxsolde.Text = "solde";
            this.checkBoxsolde.UseVisualStyleBackColor = true;
            // 
            // checkBoxsomme
            // 
            this.checkBoxsomme.AutoSize = true;
            this.checkBoxsomme.Location = new System.Drawing.Point(53, 36);
            this.checkBoxsomme.Name = "checkBoxsomme";
            this.checkBoxsomme.Size = new System.Drawing.Size(75, 21);
            this.checkBoxsomme.TabIndex = 0;
            this.checkBoxsomme.Text = "somme";
            this.checkBoxsomme.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(115, 170);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Somme";
            // 
            // textBoxsomme
            // 
            this.textBoxsomme.Location = new System.Drawing.Point(205, 170);
            this.textBoxsomme.Name = "textBoxsomme";
            this.textBoxsomme.Size = new System.Drawing.Size(142, 22);
            this.textBoxsomme.TabIndex = 3;
            // 
            // textBoxsolde
            // 
            this.textBoxsolde.Location = new System.Drawing.Point(205, 233);
            this.textBoxsolde.Name = "textBoxsolde";
            this.textBoxsolde.Size = new System.Drawing.Size(142, 22);
            this.textBoxsolde.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 233);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Solde ";
            // 
            // buttonEN
            // 
            this.buttonEN.Location = new System.Drawing.Point(552, 305);
            this.buttonEN.Name = "buttonEN";
            this.buttonEN.Size = new System.Drawing.Size(230, 23);
            this.buttonEN.TabIndex = 6;
            this.buttonEN.Text = "EnregistrementModificaton";
            this.buttonEN.UseVisualStyleBackColor = true;
            this.buttonEN.Click += new System.EventHandler(this.buttonEN_Click);
            // 
            // FormumlaireModfierCompte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 372);
            this.Controls.Add(this.buttonEN);
            this.Controls.Add(this.textBoxsolde);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxsomme);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormumlaireModfierCompte";
            this.Text = "FormumlaireModfierCompte";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBoxsolde;
        private System.Windows.Forms.CheckBox checkBoxsomme;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxsomme;
        private System.Windows.Forms.TextBox textBoxsolde;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonEN;
    }
}