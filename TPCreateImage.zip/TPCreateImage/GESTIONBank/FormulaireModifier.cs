﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GESTIONBank
{
    public partial class FormulaireModifier : Form
    {
        public FormulaireModifier()
        {
            InitializeComponent();
        }
       
        private void buttonEN_Click(object sender, EventArgs e)
        {
            textBox1.Hide();
            textBox2.Hide();
            textBox3.Hide();
            textBox4.Hide();
            if (checkBoxnom.Checked == true )
            {
                
                textBox1.Show();
                string nom = textBox1.Text;

            }
            if (checkBoxPrenom.Checked == true )
            {
                textBox2.Show();
                string Prenom = textBox2.Text;
            }
            if (checkBoxAdress.Checked == true)
            {
                textBox3.Show();
                string nom = textBox1.Text;
            }
            if (checkBoxTel.Checked == true)
            {
                textBox4.Show();
                string tel =textBox4.Text;
            }
        }
    }
    }
