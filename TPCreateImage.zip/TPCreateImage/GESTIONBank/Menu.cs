﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GESTIONBank
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormulaireAjouter FA = new FormulaireAjouter();
            FA.Show();
        }

        private void modifierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormulaireModifier FM = new FormulaireModifier();
            FM.Show();
        }

        private void ajouterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormulaireAjouterCompt FAC = new FormulaireAjouterCompt();
            FAC.Show();
        }

        private void modifierToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormumlaireModfierCompte FMC = new FormumlaireModfierCompte();
            FMC.Show();
        }

        private void transferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormulaireTransfert FT = new FormulaireTransfert();
            FT.Show();
        }

        private void crediterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormulaireCrediter CF = new FormulaireCrediter();
            CF.Show();
        }

        private void debiterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormulaireDebiter FD = new FormulaireDebiter();
            FD.Show();
        }

        private void convertirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DevisConvertir dv = new DevisConvertir();
            dv.Show();
        }
    }
}
