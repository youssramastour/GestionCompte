﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atelier1_G31
{
    class Compte
    {
        private  readonly int numcompte;
        private  static int cpt;
        private  readonly Client titulaire;
        private MAD solde;
        private  static MAD plafond;
       // private  static readonly double pi ;

        static Compte()
        {
            cpt = 0;
            plafond = new MAD(2000);
           // pi = 3.14;
        }
        public Compte(Client Titu, MAD s)
        {
            
            this.numcompte = ++cpt;
            this.titulaire = Titu;
            this.solde = s;
        }
       

        public void consulter()
        {
            Console.WriteLine("le num est : " + this.numcompte);
            this.titulaire.afficherClient();
            this.solde.afficherSolde();
        }

        public bool crediter(MAD somme)
        {
            MAD nul_Val = new MAD(0);
            if (somme > nul_Val)
            {
                this.solde += somme;
                return true;
            }
            return false;
        }

        public bool debiter(MAD somme)
        {
            MAD nul_Val = new MAD(0);
            if ( somme> nul_Val )
            {
                if (this.solde > somme)
                {
                    if (plafond > somme)
                    {
                        this.solde -= somme;
                        return true;
                    }
                    else
                    {
                        Console.WriteLine("plafond<somme");
                        return false;

                    }
                }
                else
                {

                    Console.WriteLine("solde<somme");
                    return false;
                }     
            }
            else
            {
                Console.WriteLine("somme<0");
                return false;
            }
        }

        public bool verser(Compte c, MAD somme)
        {
            if (this.debiter(somme)==true&& this.numcompte!=c.numcompte)
            {
                c.crediter(somme);
                return true;
            }
            return false;
        }



    }
}
