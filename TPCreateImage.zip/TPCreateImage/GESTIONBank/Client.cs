﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atelier1_G31
{
    class Client
    {
        private string nom;
        private string prenom;
        private string adress;
        private int tel;
        private string sex;
        public Client()
        { }

        public Client (string n, string p, string a)
        {
            this.nom = n;
            this.prenom = p;
            this.adress = a;
        }
        public Client(string n, string p, string a ,int t,string s)
        {
            this.nom = n;
            this.prenom = p;
            this.adress = a;
            this.tel = t;
            this.sex = s;
        }

        public void afficherClient()
        {
            Console.WriteLine("le nom est : " + this.nom);
            Console.WriteLine("le prenom est : " + this.prenom);
            Console.WriteLine("l'adresse est : " + this.adress);
        }



    }
}
