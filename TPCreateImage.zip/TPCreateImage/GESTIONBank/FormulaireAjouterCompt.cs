﻿using Atelier1_G31;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GESTIONBank
{
    public partial class FormulaireAjouterCompt : Form
    {
        public FormulaireAjouterCompt()
        {
            InitializeComponent();
        }

        private void btmAjoutre_Click(object sender, EventArgs e)
        {
            Compte C = new Compte(textBox2.Text, textBox5.Text);
            Program.lstCompt.Add(C);
            vider();
        }
        public void vider()
        {
           
            textBox2.ResetText();
            textBox5.Text = "";
            textBox2.Focus();
        }
    }
  }
