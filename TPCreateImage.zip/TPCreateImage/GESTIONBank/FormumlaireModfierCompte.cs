﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GESTIONBank
{
    public partial class FormumlaireModfierCompte : Form
    {
        public FormumlaireModfierCompte()
        {
            InitializeComponent();
        }

        private void buttonEN_Click(object sender, EventArgs e)
        {

            textBoxsomme.Hide();
            textBoxsolde.Hide();
            
            if (checkBoxsomme.Checked == true)
            {

                textBoxsomme.Show();
             int somme= int.Parse(textBoxsomme.Text);

            }
            if (checkBoxsolde.Checked == true)
            {
                textBoxsolde.Show();
                float solde= int.Parse(textBoxsolde.Text);
            }
        }
    }
}
