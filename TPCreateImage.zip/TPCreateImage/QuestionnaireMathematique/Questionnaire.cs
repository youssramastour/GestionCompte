﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuestionnaireMathematique
{
    public partial class Questionnaire : Form
    {
            Random randomizer = new Random();
        int addend1;
        int addend2;
        public Questionnaire()
            {
                InitializeComponent();
            }

            private void label1_Click(object sender, EventArgs e)
            {

            }
        }
}
